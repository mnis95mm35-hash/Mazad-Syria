import { CATEGORIES, CITIES } from '@/lib/sample_data';

// أسماء المدن في قاعدة البيانات عربية، ونحتاج لها روابط إنجليزية نظيفة
export const CITY_SLUGS: Record<string, string> = {
  دمشق: 'damascus',
  حلب: 'aleppo',
  حمص: 'homs',
  اللاذقية: 'latakia',
  حماة: 'hama',
  طرطوس: 'tartus',
};

export const citySlug = (name: string) => CITY_SLUGS[name] ?? null;
export const cityFromSlug = (slug: string) => CITIES.find((c) => CITY_SLUGS[c] === slug) ?? null;

export type Sub = { slug: string; label: string };

// الأقسام الفرعية لكل قسم
export const SUBCATEGORIES: Record<string, Sub[]> = {
  cars: [
    { slug: 'toyota', label: 'تويوتا' },
    { slug: 'hyundai', label: 'هيونداي' },
    { slug: 'kia', label: 'كيا' },
    { slug: 'nissan', label: 'نيسان' },
    { slug: 'mercedes', label: 'مرسيدس' },
    { slug: 'bmw', label: 'بي إم دبليو' },
    { slug: 'chevrolet', label: 'شيفروليه' },
    { slug: 'other-cars', label: 'ماركات أخرى' },
  ],
  'real-estate': [
    { slug: 'apartment-sale', label: 'شقق للبيع' },
    { slug: 'apartment-rent', label: 'شقق للإيجار' },
    { slug: 'houses-villas', label: 'بيوت وفلل' },
    { slug: 'land', label: 'أراضٍ' },
    { slug: 'shops-offices', label: 'محلات ومكاتب' },
  ],
  electronics: [
    { slug: 'phones', label: 'جوالات' },
    { slug: 'computers', label: 'حواسيب ولابتوبات' },
    { slug: 'tv-audio', label: 'تلفزيونات وصوتيات' },
    { slug: 'accessories', label: 'ملحقات' },
  ],
  furniture: [
    { slug: 'bedrooms', label: 'غرف نوم' },
    { slug: 'living-rooms', label: 'غرف جلوس' },
    { slug: 'kitchens', label: 'مطابخ' },
    { slug: 'home-appliances', label: 'أجهزة منزلية' },
  ],
  jobs: [
    { slug: 'full-time', label: 'دوام كامل' },
    { slug: 'part-time', label: 'دوام جزئي' },
    { slug: 'freelance', label: 'عمل حر' },
  ],
  services: [
    { slug: 'maintenance', label: 'صيانة وتصليح' },
    { slug: 'transport', label: 'نقل وشحن' },
    { slug: 'education', label: 'دروس وتعليم' },
    { slug: 'other-services', label: 'خدمات أخرى' },
  ],
};

export const subsOf = (category: string): Sub[] => SUBCATEGORIES[category] ?? [];
export const subLabel = (category: string, slug?: string | null) =>
  subsOf(category).find((s) => s.slug === slug)?.label ?? null;
export const isValidSub = (category: string, slug: string) => subsOf(category).some((s) => s.slug === slug);

export const categoryExists = (slug: string) => CATEGORIES.some((c) => c.slug === slug);

// مسار صفحة تصنيفية: /cars أو /cars/damascus أو /cars/toyota أو /cars/toyota/damascus
export function browsePath(p: { category: string; sub?: string | null; city?: string | null }) {
  const parts = [p.category];
  if (p.sub) parts.push(p.sub);
  const cs = p.city ? citySlug(p.city) : null;
  if (cs) parts.push(cs);
  return '/' + parts.join('/');
}

export type Currency = 'USD' | 'SYP';
export const CURRENCIES: { code: Currency; label: string }[] = [
  { code: 'USD', label: 'دولار $' },
  { code: 'SYP', label: 'ليرة سورية' },
];
export const isCurrency = (v: unknown): v is Currency => v === 'USD' || v === 'SYP';
