import Link from 'next/link';
import { SITE } from '@/lib/site_config';

export default function Navbar() {
  return (
    <header className="sticky top-0 z-20 border-b border-emerald-900/10 bg-white/90 backdrop-blur">
      <div className="container mx-auto flex items-center justify-between px-4 py-3">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-emerald-800 text-lg font-black text-amber-300">
            م
          </span>
          <span className="text-xl font-extrabold text-emerald-900">{SITE.name}</span>
        </Link>

        <nav className="hidden items-center gap-6 text-sm font-semibold text-gray-700 md:flex">
          <Link href="/" className="hover:text-emerald-800">الرئيسية</Link>
          <Link href="/?category=cars" className="hover:text-emerald-800">سيارات</Link>
          <Link href="/?category=real-estate" className="hover:text-emerald-800">عقارات</Link>
          <Link href="/?category=electronics" className="hover:text-emerald-800">إلكترونيات</Link>
          <Link href="/advertise" className="hover:text-emerald-800">أعلن معنا</Link>
        </nav>

        <Link
          href="/listings/new"
          className="rounded-xl bg-amber-400 px-5 py-2.5 text-sm font-bold text-emerald-950 shadow-sm transition hover:bg-amber-300"
        >
          + أضف إعلاناً
        </Link>
      </div>
    </header>
  );
}
